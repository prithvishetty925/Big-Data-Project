dbPassword='mongodb+srv://suhani1230:Suhani1230@cluster0.qcod3.mongodb.net/test?retryWrites=true&w=majority'

module.exports = {
  mongoURI: dbPassword
};